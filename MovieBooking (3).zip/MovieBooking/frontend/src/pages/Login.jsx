import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Formik, Form, Field, ErrorMessage } from 'formik'
import * as Yup from 'yup'
import { useAuth } from '../context/AuthContext.jsx'

const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email('Invalid email address')
    .required('Email is required'),
  password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required')
})

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const [loginAs, setLoginAs] = useState('user')

  async function handleSubmit(values, { setSubmitting }) {
    setError('')
    try {
      await login(values.email, values.password)

      const token = localStorage.getItem('token')
      if (token) {
        const payload = JSON.parse(atob(token.split('.')[1]))
        if (loginAs === 'admin') {
          if (payload.role === 'admin') {
            navigate('/admin/dashboard', { replace: true })
          } else {
            setError('This account is not an admin. Choose User or use an admin account.')
            return
          }
        } else {
          navigate('/', { replace: true })
        }
      } else {
        navigate('/', { replace: true })
      }
    } catch (err) {
      setError(err?.response?.data?.message || 'Login failed')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div
      className="login-wrapper d-flex justify-content-center align-items-center py-5"
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #9a4ce9ff, #f1f8e9)'
      }}
    >
      <div
        className="card shadow-lg border-0 p-4"
        style={{
          width: '100%',
          maxWidth: 420,
          borderRadius: '16px',
          background: 'rgba(255, 255, 255, 0.9)',
          backdropFilter: 'blur(8px)'
        }}
      >
        <div className="text-center mb-3">
          <h3 className="fw-bold text-primary mb-1">Welcome Back </h3>
          <small className="text-muted">Login to continue</small>
        </div>

        {error && <div className="alert alert-danger">{error}</div>}

        <Formik
          initialValues={{ email: '', password: '' }}
          validationSchema={loginSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting, touched, errors }) => (
            <Form>
              {/* Role Selector */}
              <div className="mb-3 d-flex gap-3 align-items-center justify-content-center">
                <span className="form-label m-0 fw-semibold text-secondary">Login as:</span>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="loginAs"
                    id="loginAsUser"
                    value="user"
                    checked={loginAs === 'user'}
                    onChange={() => setLoginAs('user')}
                  />
                  <label className="form-check-label" htmlFor="loginAsUser">
                    User
                  </label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="loginAs"
                    id="loginAsAdmin"
                    value="admin"
                    checked={loginAs === 'admin'}
                    onChange={() => setLoginAs('admin')}
                  />
                  <label className="form-check-label" htmlFor="loginAsAdmin">
                    Admin
                  </label>
                </div>
              </div>

              {/* Email */}
              <div className="mb-3">
                <label htmlFor="email" className="form-label fw-semibold">
                  Email
                </label>
                <Field
                  type="email"
                  name="email"
                  id="email"
                  className={`form-control ${
                    touched.email && errors.email ? 'is-invalid' : ''
                  }`}
                  placeholder="Enter your email"
                />
                <ErrorMessage name="email" component="div" className="invalid-feedback" />
              </div>

              {/* Password */}
              <div className="mb-3">
                <label htmlFor="password" className="form-label fw-semibold">
                  Password
                </label>
                <Field
                  type="password"
                  name="password"
                  id="password"
                  className={`form-control ${
                    touched.password && errors.password ? 'is-invalid' : ''
                  }`}
                  placeholder="Enter your password"
                />
                <ErrorMessage name="password" component="div" className="invalid-feedback" />
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn btn-primary w-100 fw-semibold"
                style={{
                  borderRadius: '8px',
                  transition: 'all 0.3s ease'
                }}
              >
                {isSubmitting ? 'Logging in...' : 'Login'}
              </button>
            </Form>
          )}
        </Formik>
      </div>

      <style>{`
        .card {
          animation: fadeInUp 0.6s ease;
        }
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .btn-primary:hover {
          background-color: #1565c0 !important;
          transform: translateY(-2px);
          box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
      `}</style>
    </div>
  )
}
